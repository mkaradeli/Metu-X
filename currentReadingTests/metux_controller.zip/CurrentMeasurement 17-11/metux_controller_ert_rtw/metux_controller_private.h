/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: metux_controller_private.h
 *
 * Code generated for Simulink model 'metux_controller'.
 *
 * Model version                  : 5.22
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sat Nov 29 18:40:47 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef metux_controller_private_h_
#define metux_controller_private_h_
#include "rtwtypes.h"
#include "metux_controller_types.h"
#define SimulinkModelVersion           5.22
#endif                                 /* metux_controller_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
