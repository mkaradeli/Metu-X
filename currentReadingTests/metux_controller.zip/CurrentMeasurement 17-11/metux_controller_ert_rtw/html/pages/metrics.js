function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["enableKalmanForPositionEst"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 8};
	 this.metricsArray.var["enableKalmanForVelocityEst"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 8};
	 this.metricsArray.var["metux_controller.c:metux_controller_M_"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 4};
	 this.metricsArray.var["metux_controller_B"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 24};
	 this.metricsArray.var["metux_controller_DW"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 136};
	 this.metricsArray.var["metux_controller_U"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 80};
	 this.metricsArray.var["metux_controller_Y"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 80};
	 this.metricsArray.var["position_controller"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 64};
	 this.metricsArray.var["velocity_controller"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	size: 40};
	 this.metricsArray.fcn["memset"] = {file: "/Applications/MATLAB_R2025b.app/polyspace/verifier/cxx/include/include-libc/string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["metux_controller_initialize"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["metux_controller_step"] = {file: "/Users/karadeli/Documents/Metu-X/CurrentMeasurement 17-11/metux_controller_ert_rtw/metux_controller.c",
	stack: 113,
	stackTotal: 113};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'metux_controller_metrics\'});">Global Memory: 444(bytes) Maximum Stack: 113(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
